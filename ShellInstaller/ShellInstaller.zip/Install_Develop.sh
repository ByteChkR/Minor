#!/bin/bash
printf 'develop'|/bin/bash EngineInstaller.sh
