#!/bin/bash
printf 'master'|/bin/bash EngineInstaller.sh
